package com.example.timer_provider

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
