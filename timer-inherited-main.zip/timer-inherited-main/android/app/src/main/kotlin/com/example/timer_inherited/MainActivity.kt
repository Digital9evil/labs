package com.example.timer_inherited

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
