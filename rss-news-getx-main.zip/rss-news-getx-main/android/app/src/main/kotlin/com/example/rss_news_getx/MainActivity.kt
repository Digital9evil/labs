package com.example.rss_news_getx

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
