package com.example.timer_lab

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
